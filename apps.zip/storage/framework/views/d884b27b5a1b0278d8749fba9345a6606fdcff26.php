

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
       
           <h2 class=" text-warning">
               Registration is not allowed
           </h2>
       
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.skyspace', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\national-college\resources\views/auth/register.blade.php ENDPATH**/ ?>