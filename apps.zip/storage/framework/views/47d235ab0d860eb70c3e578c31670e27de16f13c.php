

<?php $__env->startSection('content'); ?>
<div class="col-md-4">


    Email
    <div class="card">
        <div class="card-body login-card-body">
          <p class="login-box-msg">You forgot your password? Here you can easily retrieve a new password.</p>
    
          <form action="<?php echo e(route('password.email')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-0">
              <input type="email" class="form-control" placeholder="Email" name="email" />
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-envelope"></span>
                </div>
              </div>
            </div>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p class="text-sm text-danger"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="row py-3">
              <div class="col-12">
                <button type="submit" class="btn btn-warning btn-block">Reset password</button>
              </div>
              <!-- /.col -->
            </div>
          </form>
    
          <p class="mt-3 mb-1">
            <a href="<?php echo e(route('login')); ?>">Login</a>
          </p>
         
        </div>
        <!-- /.login-card-body -->
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.skyspace', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\national-college\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>