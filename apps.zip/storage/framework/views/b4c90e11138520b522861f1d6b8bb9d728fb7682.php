<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>National College</title>

    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
    

    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

    <div class="container-fluid bg-info d-flex justify-content-center align-items-center" style="height: 100vh">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>


</html>
<?php /**PATH D:\Laravel\national-college\resources\views/layouts/skyspace.blade.php ENDPATH**/ ?>