

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Event Add</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Event create</li>
                    </ol>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content mb-2">
        <form action="<?php echo e(route('admin.event.update', $event)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Event</h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="inputName">Event title</label>
                                <input type="text" id="inputName" class="form-control" name="title"
                                    value="<?php echo e($event->title); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="inputDescription">Event Description</label>
                                <textarea id="inputDescription" class="form-control" rows="4"
                                    name="description"> <?php echo e($event->description); ?> </textarea>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <!-- Date and time range -->
                                    <div class="form-group">
                                        <label>Event time</label>

                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="far fa-clock"></i></span>
                                            </div>
                                            <input name="eventTimeRange" type="text" class="form-control float-right"
                                                id="eventRange">
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                    <!-- /.form group -->
                                </div>


                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="attachment">Change Event Picture</label>

                                        <div class="row">
                                            <div class="col-9">
                                                <input id="attachment" class="form-control custom-select" type="file"
                                                    name="attachment" accept="image/*">
                                            </div>
                                            <?php if(isset($event->event_picture)): ?>
                                                <div class="col-3">
                                                    <a class="btn btn-info px-5"
                                                        href="<?php echo e(asset('storage/' . $event->event_picture)); ?>"
                                                        target="_blank">
                                                        View
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                        <div class="row p-4">
                            <div class="col-12">
                                <a href="<?php echo e(route('admin.index')); ?>" class="btn btn-secondary">Cancel</a>
                                <input type="submit" value="Update event" class="btn btn-success float-right">
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </form>
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/daterangepicker/daterangepicker.js')); ?>"></script>

    <script>
        $(function() {
            $('#eventRange').daterangepicker({
                timePicker: true,
                timePickerIncrement: 15,
                locale: {
                    format: 'DD/MM/YYYY hh:mm A'
                },
                minDate: '<?php echo e(date('d-m-Y')); ?>',
                maxDate: '<?php echo e(date('d-m-Y', strtotime('+1 year'))); ?>',
                startDate: '<?php echo e($event->startTime); ?>',
                endDate: '<?php echo e($event->endTime); ?>'
            })
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\national-college\resources\views/admin/event/edit.blade.php ENDPATH**/ ?>