@extends('layouts.skyspace')

@section('content')
<div class="container">
    <div class="row justify-content-center">
       
           <h2 class=" text-warning">
               Registration is not allowed
           </h2>
       
    </div>
</div>
@endsection
